
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getMarketingAdvice = async (
  query: string,
  contextData: string
): Promise<string> => {
  try {
    const systemInstruction = `You are an expert Digital Media Buyer and Marketing Analyst. 
    You help users understand metrics like CPM (Cost Per Mille), CPV (Cost Per View), and ROI.
    Keep your answers concise, practical, and action-oriented.
    If the user provides specific numbers (Budget, Impressions, Views), analyze them.
    
    Benchmarks for reference:
    - Average Social CPM: $5 - $20
    - Average Display CPM: $2 - $10
    - Average CPV (YouTube/Social): $0.01 - $0.10
    
    Provide context on whether their calculated metrics are good or bad based on these general benchmarks.`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Context Data: ${contextData}\n\nUser Question: ${query}`,
      config: {
        systemInstruction: systemInstruction,
        temperature: 0.7,
      }
    });

    return response.text || "I couldn't generate a response. Please try again.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw new Error("Failed to fetch advice from Gemini.");
  }
};
